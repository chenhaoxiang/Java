package cn.hncu.demo1.login.dao;

import cn.hncu.demo1.domain.Person;

public interface LoginDAO {
	public void login(Person p);
}
