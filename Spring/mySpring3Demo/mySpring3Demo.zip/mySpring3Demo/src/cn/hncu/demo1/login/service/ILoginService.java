package cn.hncu.demo1.login.service;

import cn.hncu.demo1.domain.Person;

public interface ILoginService {

	public void login(Person p);
   
}
