package cn.hncu.bookStore.book.vo;

public class BookQueryModel extends BookModel{
	private double inPrice2;
	private double salePrice2;
	public double getInPrice2() {
		return inPrice2;
	}
	public void setInPrice2(double inPrice2) {
		this.inPrice2 = inPrice2;
	}
	public double getSalePrice2() {
		return salePrice2;
	}
	public void setSalePrice2(double salePrice2) {
		this.salePrice2 = salePrice2;
	}
	
	
}
