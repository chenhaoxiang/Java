package cn.hncu.bookStore.user.vo;
/**
 * 
 * @author �º���
 *
 * @version 1.0
 */
public class UserQueryModel extends UserModel{
	
}
