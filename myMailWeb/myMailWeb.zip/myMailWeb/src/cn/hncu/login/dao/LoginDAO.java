package cn.hncu.login.dao;

import cn.hncu.domain.User;

public interface LoginDAO {
	public User login(User u);
}
