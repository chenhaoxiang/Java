package cn.hncu.login.service;

import cn.hncu.domain.User;

public interface ILoginService {
	public User login(User u);
}
